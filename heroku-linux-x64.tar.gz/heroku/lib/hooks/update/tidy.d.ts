import { Hook } from '@oclif/core';
export declare const tidy: Hook<'update'>;
