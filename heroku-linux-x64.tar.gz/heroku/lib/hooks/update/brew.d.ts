import { Hook } from '@oclif/core';
export declare const brewHook: Hook<'update'>;
