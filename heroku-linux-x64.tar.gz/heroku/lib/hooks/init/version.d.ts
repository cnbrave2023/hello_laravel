import { Hook } from '@oclif/core';
export declare const version: Hook.Init;
