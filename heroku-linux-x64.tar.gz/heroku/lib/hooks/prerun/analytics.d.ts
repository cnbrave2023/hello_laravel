import { Hook } from '@oclif/core';
export declare const analytics: Hook<'prerun'>;
